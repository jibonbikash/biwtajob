<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
				{{ date('Y') }}  &copy; BIWTA. All Rights Reserved.
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->
