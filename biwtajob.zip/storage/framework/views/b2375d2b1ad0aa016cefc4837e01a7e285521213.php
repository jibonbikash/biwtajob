<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <!-- Scripts -->
</head>
<body>

<div class="container">

        <img src="https://jobsbiwta.gov.bd/website/wp-content/uploads/2013/06/biwta_banner_new-03-copy.jpg" alt="" style="width: 100%; max-height: 200px" />

    <nav class="navbar navbar-expand-lg  mt-1 navbar-dark bg-primary mb-3">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e((request()->is('/')) ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(URL::to('/')); ?>">Current Job  Circular</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e((request()->is('printCopy')) ? 'active' : ''); ?>" href="<?php echo e(route('PrintCopy')); ?>">Applicant  Copy Print</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e((request()->is('writtenCopy')) ? 'active' : ''); ?>" href="<?php echo e(route('writtenCopy')); ?>">লিখিত পরীক্ষার প্রবেশ পত্র</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link <?php echo e((request()->is('vivaCopy')) ? 'active' : ''); ?>" href="<?php echo e(route('vivaCopy')); ?>">মৌখিক পরীক্ষার প্রবেশ পত্র</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e((request()->is('practicalCopy')) ? 'active' : ''); ?>" href="<?php echo e(route('practicalCopy')); ?>">ব্যবহারিক পরীক্ষার প্রবেশ পত্র</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e((request()->is('medicalCopy')) ? 'active' : ''); ?>" href="<?php echo e(route('medicalCopy')); ?>">স্বাস্থ্য পরীক্ষার প্রবেশপত্র</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Search Applied ID</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <script>
        feather.replace()
    </script>
<?php echo $__env->yieldContent('script-bottom'); ?>
<style>
    .nav-link{
        color: white;
    }
    .navbar-nav .nav-link.active, .navbar-nav .show>.nav-link{
        font-weight: 600;
    }
</style>
</body>
</html>
<?php /**PATH /mnt/39765386-d363-4c92-b216-770afe86e597/Laravel Project/biwtajob/resources/views/layouts/app.blade.php ENDPATH**/ ?>