<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Vacancies')); ?></div>
                <div class="card-body">
                    <?php echo $__env->make('layouts.shared.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered">
                        <thead>
                        <tr class="table-secondary">
                            <th scope="col">#</th>
                            <th scope="col">Position</th>
                            <th scope="col">Number of total post</th>
                            <th scope="col">Job circular no</th>
                            <th scope="col">Last date of application</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <th scope="row"><?php echo e($loop->iteration + $jobs->firstItem() - 1); ?></th>
                            <td>
                                <a href="<?php echo e(route('details',['uuid'=>$job->uuid])); ?>">
                                <?php echo e($job->title); ?>

                                </a></td>
                            <td><?php echo e($job->vacancies); ?></td>
                            <td><?php echo e($job->job_id); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($job->application_deadline)->format('F j, Y')); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                    <nav aria-label="Page navigation example">
                    <?php echo e($jobs->appends(Request::all())->links('pagination::bootstrap-5')); ?>

                    </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/39765386-d363-4c92-b216-770afe86e597/Laravel Project/biwtajob/resources/views/home.blade.php ENDPATH**/ ?>