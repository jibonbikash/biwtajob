<?php
/**
 * Created by  jibon Bikash Roy.
 * User: jibon
 * Date: ১/৪/২৩
 * Time: ৮:২০ PM
 * Copyright jibon <jibon.bikash@gmail.com>
 */
?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header fw-bold">
                    মৌখিক পরীক্ষার প্রবেশ পত্র
                </div>
                <div class="card-body">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Applied Code" aria-label="Applied Code" aria-describedby="button-addon2">
                        <button class="btn btn-primary" type="submit" id="button-addon2"><i data-feather="search"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/39765386-d363-4c92-b216-770afe86e597/Laravel Project/biwtajob/resources/views/jobs/vivaCard.blade.php ENDPATH**/ ?>