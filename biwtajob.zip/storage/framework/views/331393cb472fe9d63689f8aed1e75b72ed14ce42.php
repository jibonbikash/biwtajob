<?php
/**
 * Created by  jibon Bikash Roy.
 * User: jibon
 * Date: ৩/২/২৩
 * Time: ৮:১১ PM
 * Copyright jibon <jibon.bikash@gmail.com>
 */
?>


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <table class="table table-striped table-bordered">

            <tbody>
            <tr>
                <th scope="row">Title</th>
                <td><?php echo e($job->title); ?></td>
            </tr>
            <tr>
                <th scope="row">Application Fee</th>
                <td><span class="badge bg-primary rounded-pill"><?php echo e($job->apply_fee); ?></span> BDT</td>
            </tr>
            <tr>
                <th scope="row">No. of Vacancies</th>
                <td><?php echo e($job->vacancies); ?></td>
            </tr>

           <tr>
                <th scope="row">Application Deadline</th>
                <td><?php echo e(Carbon\Carbon::parse($job->application_deadline)->format('F j, Y')); ?></td>
            </tr>
            <tr>
                <th scope="row" class="align-top">Job Description / Responsibility</th>
                <td><?php echo $job->description; ?></td>
            </tr>

            </tbody>
            <tfoot>
            <tr>
                <td colspan="2">
                    <div class="float-end">
                        <a class="btn btn-primary btn-lg" href="<?php echo e(route('applyform',['uuid'=>$job->uuid])); ?>"> Apply  <i data-feather="arrow-right-circle"></i> </a>
                    </div>

                </td>
            </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/39765386-d363-4c92-b216-770afe86e597/Laravel Project/biwtajob/resources/views/jobs/details.blade.php ENDPATH**/ ?>